function getTime() {
    const now = new Date();
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const seconds = now.getSeconds();
    return `${hours}:${minutes}:${seconds}`;
  }
  

  function updateTime() {
    const timeElement = document.getElementById("time");
    timeElement.textContent = getTime();
    setTimeout(updateTime, 1000);
  }
  

  updateTime();
  
  let date = new Date();
  let hour = date.getHours();
  let greeting;
  
  if (hour >= 5 && hour < 12) {
    greeting = "Good morning";
  } else if (hour >= 12 && hour < 18) {
    greeting = "Good afternoon";
  } else if (hour >= 18 && hour < 22) {
    greeting = "Good evening";
  } else {
    greeting = "Good night";
  }
  
  const foodBar = document.getElementById("food-bar");
  const gameBar = document.getElementById("game-bar");
  const sleepBar = document.getElementById("sleep-bar");
  const healthBar = document.getElementById("health-bar");
  
  function decreaseBar(barElement) {
    const barValue = parseInt(barElement.firstChild.style.width) || 100;
    if (barValue > 0) {
      barElement.firstChild.style.width = (barValue - 1) + "%";
    }
  }
  
  function increaseSleepBar() {
    const barValue = parseInt(sleepBar.firstChild.style.width) || 0;
    if (barValue < 100) {
      sleepBar.firstChild.style.width = (barValue + 1) + "%";
    }
  }
  
  setInterval(function() {
    decreaseBar(foodBar);
    decreaseBar(gameBar);
    decreaseBar(sleepBar);
    decreaseBar(healthBar);
  }, 1000);
  
  function feed() {
    const barValue = parseInt(foodBar.firstChild.style.width) || 0;
    if (barValue < 100) {
      foodBar.firstChild.style.width = (barValue + 10) + "%";
    }
  }
  
  function play() {
    const barValue = parseInt(gameBar.firstChild.style.width) || 0;
    if (barValue < 100) {
      gameBar.firstChild.style.width = (barValue + 10) + "%";
    }
  }
  
  function putToBed() {
    increaseSleepBar();
  }
  
  function giveMedicine() {
    const barValue = parseInt(healthBar.firstChild.style.width) || 0;
    if (barValue < 100) {
      healthBar.firstChild.style.width = (barValue + 10) + "%";
    }
  }
  
  document.getElementById("greeting").textContent = greeting;
  
  const selectedCatImg = document.getElementById("selected-cat-img");
  const selectedPetName = document.getElementById("selected-pet-name");
  
  const selectedCat = localStorage.getItem("selectedCat");
  const petName = localStorage.getItem("petName");
  
  selectedCatImg.src = selectedCat;
  selectedPetName.textContent = petName;
  

  document.getElementById("feed-button").addEventListener("click", feed);
  document.getElementById("play-button").addEventListener("click", play);
  document.getElementById("sleep-button").addEventListener("click", putToBed);
  document.getElementById("medicine-button").addEventListener("click", giveMedicine);
  
  
  
  
  
  

  
      