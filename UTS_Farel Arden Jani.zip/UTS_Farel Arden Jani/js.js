var catIndex = 0;
var catImages = ["cat1.jpg", "cat2.jpg", "cat3.jpg"];

function showCat() {
  var catImg = document.getElementById("cat-img");
  catImg.src = catImages[catIndex];
}

function nextCat() {
  catIndex++;
  if (catIndex >= catImages.length) {
    catIndex = 0;
  }
  showCat();
}

function prevCat() {
  catIndex--;
  if (catIndex < 0) {
    catIndex = catImages.length - 1;
  }
  showCat();
}

showCat();
